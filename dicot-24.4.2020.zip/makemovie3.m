%% 24/2/2018 Anushree, iiser pune
%% Modified Anushree 20/03/2020
%% Modified 7/3/2018
%% Yash MOD 15Nov2019
%% Overlay tracks on images in real time i.e. make a tracking movie
function makemovie3(Findex,info,outfolder,imagename,outmat,tracks)
%% INPUT:
% Findex = frame nos. start:end
% imagename = tif time-series
% outmat = tracked output matrix from 'trackbeads.m' 
% (1:obj no, 2:frame, 3:x, 4:y, 5:length, 6:time)
% tracks = structure array from 'trackbeads.m'
%% OUTPUT:
% trackingmovie.tif = output tif movie
% trajectoryplot.tif = output plot overlaid on image
%% CODE:
outfile1=[outfolder, '/trackingmovie.tif'];
outfile2=[outfolder,'/trajectoryplot.tif'];
outfile3=[outfolder,'/trajectoryplot.svg'];%Y

if exist(outfile1, 'file') 
    delete(outfile1);
end
if exist(outfile2, 'file') 
    delete(outfile2);
end
%% movie
% outmat:  obj no, frame, x, y, length, time 
objno=unique(outmat(:,1));
objwise=cell(1, max(objno));
frmwise=cell(1,Findex(end));
p=0;
w =waitbar(0, 'Saving movie..');
movegui(w, 'north');
for j=Findex
    p=p+1;
    waitbar(p/numel(Findex));
    r=find(outmat(:,2)==j);
    frmwise{j}=[outmat(r,1), outmat(r,3:4),outmat(r,2)]; %obj no, x, y, frame
    fiG= imread(imagename,j,'Info',info);
    fj= figure(j); 
    set(fj,'visible', 'off'), imshow(imadjust(fiG), 'Border', 'tight')%, 'InitialMagnification', 'fit')
    
    for i=min(objno):max(objno)
        rr= find(frmwise{j}(:,1)==i);
        objwise{i}=[objwise{i}; frmwise{j}(rr,2:3)];% x,y
                   
        if j==frmwise{j}(rr,4)
        set(gca, 'visible', 'off')
        hold on,plot(objwise{i}(1:end,1),objwise{i}(1:end,2),...
            '-r', 'Linewidth', 0.5)%, 'MarkerSize', 1)
        hold on, plot(objwise{i}(end,1),objwise{i}(end,2),'.b','MarkerSize', 4)
%         hold on, text(objwise{i}(end,1),objwise{i}(end,2),sprintf('%i', i),...
%             'Color', 'y','FontSize', 10)
        else
            continue
        end
    end
    f=getframe(gcf);
    imwrite(f.cdata, outfile1, 'tif', 'Compression', 'none', 'WriteMode', 'append');    
    delete(fj);
end
delete(w);

% %% movie MOD traject-plot
% % outmat:  obj no, frame, x, y, length, time 
% objno=unique(outmat(:,1));
% objwise=cell(1, max(objno));
% frmwise=cell(1,Findex(end));
% p=0;
% w =waitbar(0, 'Saving traj plot..');
% movegui(w, 'north');
% fiG= imread(imagename,1,'Info',info);
% fj= figure(100); 
% set(fj,'visible', 'on'), imshow(fiG, 'Border', 'tight')
% for j=1:1:1%Findex
%     p=p+1;
%     waitbar(p/numel(Findex));
%     r=find(outmat(:,2)==j);
%     frmwise{j}=[outmat(r,1), outmat(r,3:4),outmat(r,2)]; %obj no, x, y, frame
% %     fiG= imread(imagename,j,'Info',info);
% %     fj= figure(j); 
% %     set(fj,'visible', 'off'), imshow(fiG, 'Border', 'tight')%, 'InitialMagnification', 'fit')
%     
%     for i=min(objno):max(objno)
%         rr= find(frmwise{j}(:,1)==i);
%         objwise{i}=[objwise{i}; frmwise{j}(rr,2:3)];% x,y
%                    
%         if j==frmwise{j}(rr,4)
% %         set(gca, 'visible', 'off')
%         hold on,plot(objwise{i}(1:end,1),objwise{i}(1:end,2),...
%             '-r.', 'Linewidth', 2, 'MarkerSize', 5)%Y
%         hold on, plot(objwise{i}(end,1),objwise{i}(end,2),'.b','MarkerSize', 10)
% %         hold on, text(objwise{i}(end,1),objwise{i}(end,2),sprintf('%i', i),...
% %             'Color', 'y','FontSize', 10)
%         else
%             continue
%         end
%     end
% %     f=getframe(gcf);
% %     imwrite(f.cdata, outfile1, 'tif', 'Compression', 'none', 'WriteMode', 'append');    
% %     delete(fj);
% end
% print(figure(100), '-painters', '-dsvg', outfile3);
% print(figure(100), '-dtiffnocompression', outfile2);
% delete(w);

%% trajectories overlaid on first image

% save debugt.mat tracks

fiG= imread(imagename,Findex(1),'Info',info);
fgz = figure(1000);%movegui(gcf, 'west');
% set(gcf,'NumberTitle','off', 'Name', 'Trajectory Plot');
set(fgz,'visible', 'off'), imshow(imadjust(fiG), 'Border', 'tight');%,'Initialmagnification', 'fit');
plott = 1; d = 1;
while plott 
% for d=1:size(tracks,2)
    current_track = tracks(d).frame;
    if ismember(1, current_track)
        X_array = tracks(d).x;
        Y_array = tracks(d).y;
        hold on, plot(X_array(1:end),...
            Y_array(1:end), '-r' )
        hold on, plot(X_array(1),...
            Y_array(1), '.b' )
%     hold on, text( tracks(d).x(1),...
%         tracks(d).y(1),...
%         sprintf('%i',d),...
%         'Color', 'y',...
%         'FontSize', 10);
    else
%         break
        plott = 0;
    end
    d = d+1;
end
% print(figure(1000), '-dtiffnocompression', outfile2);
f=getframe(gcf);
imwrite(f.cdata, outfile2, 'tif', 'Compression', 'none');
print(figure(1000), '-painters', '-dsvg', outfile3);



