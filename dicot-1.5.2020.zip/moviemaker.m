function moviemaker(folder,outmat,framestart,frameend,objno,img)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
tic
outfile1=[folder, '/trackingmovie.tif'];
            
            if exist(outfile1, 'file')
                delete(outfile1);
            end
            
            %% movie
            % outmat:  obj no, frame, x, y, length, time
            
            objwise=cell(1,objno);
            frmwise=cell(1,frameend);
            p=0;
            w =waitbar(0, 'Saving movie..');
            
            for j=framestart:frameend
                p=p+1;
                waitbar(p/frameend-framestart+1);
                frmwise{j}=outmat((outmat(:,2)==j),1:4); %obj no, frame, x, y
                fj= figure(j);
                set(fj,'visible', 'off'), imshow(imadjust(img{j}), 'Border', 'tight')%, 'InitialMagnification', 'fit')
                
                for i=1:objno
                    objwise{i}=[objwise{i}; frmwise{j}(frmwise{j}(:,1)==i,3:4)];% x,y
                    switch j
                        case frmwise{j}(frmwise{j}(:,1)==i,2)
                        set(gca, 'visible', 'off')
                        hold on,plot(objwise{i}(1:end,1),objwise{i}(1:end,2),...
                            '-r', 'Linewidth', 0.5)
                        hold on, plot(objwise{i}(end,1),objwise{i}(end,2),'.b','MarkerSize', 4)
                        
                        otherwise
                        continue
                    end
                end
                f=getframe(fj);
                imwrite(f.cdata, outfile1, 'tif', 'Compression', 'none', 'WriteMode', 'append');
                delete(fj);
            end
            delete(w)
            toc
end

