%%-------------------------------------------------------------------------
function [from,to, orphan]= beadsorterMod(connections, pixel_search_radius)
% All bead tracking is done here.  Everything else is bookkeeping.  NOT ROBUST.  Look here first for problems!
% find indices of minimum value in each row 
% Get all hits within the search radius 

% for r = 1:size(connections)
% [i,j] = find(connections < pixel_search_radius); 
% end 
% completed in beadSorterMod2 


[i,j]  = min(connections,[],2); % j is the row index
orphan=find(i > pixel_search_radius); 
ColArray = 1:size(connections,1);
ColArray(orphan) = [];
j(orphan) = []; 
%from=find(sum(connections,2)==1); % connected to only ONE bead in next frame:  from(i) -> 1 bead
from = ColArray'; 
%to=find(sum(connections,1)==1)'; % connected from only ONE bead in previous frame: 1 bead -> to(i)
to = j; 
orphan=setdiff(1:size(connections,2),to);

%[i,j]=find(connections(from,to)); % returns list of row,column indices of nonzero entries in good subset of correction
%from=from(i); to=to(j);  % translate list indices to row,column numbers.

%orphan=setdiff(1:size(connections,2),to); % anyone not pointed to is an orphan

