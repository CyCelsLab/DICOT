%% ARC modified March 2019
%%ARC Modified 24/2/2018
% Neha Khetan,  22 Jan 2015: for the MSD fit.

% Example to show basic fit funtion

function [d_eff,v,ce1,predy]= msd_fit_ARCmod_drift(tim,msd)

  % tim: for delta time values
  % msd: for the msd values obtained from the fit

% fit function options   -- You can specify al the fit options else the default is read: Method, Algorithm , lower n upper bounds , startpoints ,
s= fitoptions('Method','NonlinearLeastSquares',...
     'Startpoint',[ 0 0 0],...
    'Algorithm' , 'Levenberg-Marquardt' ); 

% for 2D MSD function: <r^2> =  4Dt^alpha, here tim = x;

ft3     = fittype( '(4.*d.*(x)) + ((v*x)^2) + ce1',...
    'coefficients',{'d','v', 'ce1'},'options',s );
[ cf,s1,~ ] = fit( tim , msd, ft3 );
% returns alpha and effective D values
v = cf.v;
d_eff = cf.d;
ce1=cf.ce1;
predy=cf(tim);
    
%    figure(gcf),hold on, plot(cf,'-r', 'Linewidth',2),
%    legend('off')

end
